export const data = {
  "key": "v-7df20a7e",
  "path": "/%E5%9F%BA%E7%A1%80%E7%BB%84%E4%BB%B6/Checkout%20%E5%A4%9A%E9%80%89%E6%A1%86.html",
  "title": "多选框",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": "基础组件/Checkout 多选框.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
