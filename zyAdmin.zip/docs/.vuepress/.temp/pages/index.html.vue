<template><h1 id="安装" tabindex="-1"><a class="header-anchor" href="#安装" aria-hidden="true">#</a> 安装</h1>
<p>等后面再写呗</p>
<p><a href="https://v2.vuepress.vuejs.org/zh/reference/default-theme/config.html#sidebar" target="_blank" rel="noopener noreferrer">https://v2.vuepress.vuejs.org/zh/reference/default-theme/config.html#sidebar<ExternalLinkIcon/></a></p>
</template>
