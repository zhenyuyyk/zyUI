import clientAppEnhance0 from 'D:/myProject/zyAdmin/node_modules/@vuepress/plugin-external-link-icon/lib/client/clientAppEnhance.js'
import clientAppEnhance1 from 'D:/myProject/zyAdmin/node_modules/@vuepress/plugin-medium-zoom/lib/client/clientAppEnhance.js'
import clientAppEnhance2 from 'D:/myProject/zyAdmin/node_modules/@vuepress/plugin-theme-data/lib/client/clientAppEnhance.js'
import clientAppEnhance3 from 'D:/myProject/zyAdmin/node_modules/@vuepress/theme-default/lib/client/clientAppEnhance.js'

export const clientAppEnhances = [
  clientAppEnhance0,
  clientAppEnhance1,
  clientAppEnhance2,
  clientAppEnhance3,
]
