export const pagesData = {
  // path: /
  "v-8daa1a0e": () => import(/* webpackChunkName: "v-8daa1a0e" */"D:/myProject/zyAdmin/docs/.vuepress/.temp/pages/index.html.js").then(({ data }) => data),
  // path: /%E5%9F%BA%E7%A1%80%E7%BB%84%E4%BB%B6/Checkout%20%E5%A4%9A%E9%80%89%E6%A1%86.html
  "v-7df20a7e": () => import(/* webpackChunkName: "v-7df20a7e" */"D:/myProject/zyAdmin/docs/.vuepress/.temp/pages/基础组件/Checkout 多选框.html.js").then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(/* webpackChunkName: "v-3706649a" */"D:/myProject/zyAdmin/docs/.vuepress/.temp/pages/404.html.js").then(({ data }) => data),
}
