import clientAppRootComponent0 from 'D:/myProject/zyAdmin/node_modules/@vuepress/plugin-back-to-top/lib/client/components/BackToTop.js'

export const clientAppRootComponents = [
  clientAppRootComponent0,
]
