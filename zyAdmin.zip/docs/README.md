# 安装

等后面再写呗

<https://v2.vuepress.vuejs.org/zh/reference/default-theme/config.html#sidebar>
