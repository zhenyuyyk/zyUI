<script setup>
import {ref} from 'vue';
import {ElConfigProvider} from 'element-plus';
import zhCn from 'element-plus/lib/locale/lang/zh-cn';

const locale = zhCn;
const checked1 = ref([1, 2]);
const checked2 = ref("0");
const config = {
  options: [
    {
      label: '唱',
      value: 1
    },
    {
      label: '跳',
      value: 2
    },
  ]
};
const config2 = {
  label: "你好",
  // trueLabel: "1",
  // falseLabel: "0"
};

const checkoutChange = (val) => {
  console.log("checkoutChange", val);
};

let pageConfig = {
  pageSize: 15,
  pageNo: 1,
  total: 50
};
let tableConfig = {
  border: false,
  cellClick: (row, column, cell, event) => {
    console.log(row, column, cell, event);
  }
};
let tableData = [
  {
    data: "123",
    name: "456"
  }, {
    data: "123",
    name: "456"
  }, {
    data: "123",
    name: "456"
  }
];
let tableColumn = [
  {
    label: "",
    prop: "selection",
    type: "selection",
  },
  {
    label: "Data",
    prop: "data"
  },
  {
    label: "Name",
    prop: "name",
  },
  {
    label: "操作",
    prop: "operate"
  },
];
import {ElTable} from 'element-plus';

const multipleTableRef = ref(null);
const allXuan = () => {
  console.log(multipleTableRef.value);
  // multipleTableRef.value.clearSelection();
};
console.log("app", multipleTableRef.value);
</script>

<template>
  <ElConfigProvider :locale="locale">
    <p>{{ checked2 }}</p>
    <zy-checkout-group v-model="checked1" :config="config"/>
    <zy-checkout v-model="checked2" :config="config2" @change="checkoutChange"/>
    <el-button @click="allXuan">点击全选</el-button>
    <zy-table ref="multipleTableRef" :pageConfig="pageConfig" :tableConfig="tableConfig" :column="tableColumn"
              :data="tableData"/>
  </ElConfigProvider>
</template>

<style scoped>

</style>
