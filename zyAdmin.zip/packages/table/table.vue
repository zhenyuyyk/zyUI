<script setup>
import {ref, nextTick, defineExpose, watch, computed,onMounted} from "vue";
import Page from "./pagination.vue";
import BaseTable from "./baseTable.vue";
import {tableDefault} from "../../utils/default";

const props = defineProps({
  pageConfig: {
    type: Object,
    default: {}
  },
  tableConfig: {
    type: Object,
    default: {}
  },
  column: {
    type: Object,
    default: {}
  },
  data: {
    type: Array,
    default: []
  },
});

const baseTables = ref(null);
const ccc = () => {
  console.log("123");
  console.log(baseTables.value.elTables);
  baseTables.value.elTables.clearSelection();
};
console.log("t", baseTables.value);
// nextTick(()=>{
//   defineExpose({
//     baseTables: baseTables.value?.elTables
//   });
// });
// await nextTick();
defineExpose({
  baseTables: baseTables.value?.elTables
});
</script>

<template>
  <div class="zy_table">
    <div class="zy_table_top">
      <div @click="ccc">
        插槽
      </div>
      <Page :pages="props.pageConfig"/>
    </div>
    <BaseTable ref="baseTables" :tableConfig="props.tableConfig" :column="props.column" :data="props.data"/>
  </div>
</template>

<style scoped>
.zy_table {
  width: 100%;
  box-sizing: border-box;
  padding: 16px;
}

.zy_table_top {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>
