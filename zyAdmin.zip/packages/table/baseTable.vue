<script setup>
import {computed, onMounted, ref} from "vue";
import {tableDefault, tableColumnDefault} from "/utils/default.js";
import {getType} from "/utils/utils.js";

const props = defineProps({
  tableConfig: {
    type: Object,
    default: {}
  },
  column: {
    type: Object,
    default: {}
  },
  data: {
    type: Array,
    default: []
  }
});

const tableConfig = computed(() => {
  return {
    ...tableDefault,
    ...props.tableConfig
  };
});

const tableEvent = computed(() => {
  let data = {};
  let config = props.tableConfig;
  for (let i in config) {
    getType(config[i]) === "function" ?
        data[i] = config[i] : "";
  }
  return data;
});

const column = computed(() => {
  let data = [];
  props.column.forEach((item) => {
    data.push({
      ...tableColumnDefault,
      ...item,
    });
  });
  return data;
});

const elTables = ref(null);
defineExpose({
  elTables
})
console.log("bt",elTables.value)

const ddd = () => {
  elTables.value.clearSelection()
  console.log(elTables.value);
};
</script>

<template>
  <p @click="ddd">点击</p>
  <el-table ref="elTables" class="zy_base_table" :data="props.data" v-bind="tableConfig" v-on="tableEvent">
    <el-table-column v-for="item in column" v-bind="item"/>
  </el-table>
</template>

<style scoped>
.zy_base_table {
  width: 100%;
  margin: 16px 0;
}
</style>
